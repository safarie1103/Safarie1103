<!doctype html>
<html><head lang="en">
<title>PHP Exercise 2</title>
</head>

<body>
Contact List:
<br><br>
<?php
include 'exercise2_ContactDB.php'
?>
</body>
</html>
