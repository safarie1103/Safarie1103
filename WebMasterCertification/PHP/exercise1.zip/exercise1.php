<!doctype html>
<html><head lang="en">
<title>PHP Exercise 1</title>
</head>

<body>
Hello. Executing a PHP file..!
    <br>
    <?php
$var1 = "first value<br>";
$var2 = "second value<br>";
$var3 = "third value<br>";
    echo "printing some values from PHP...<br>";
echo $var1 . " " . $var2 . " " . $var3;

?>
Goodbye!
</body>
</html>
