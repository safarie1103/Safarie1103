class ExponentialExplosion
{
  public static void main ( String[] args )
  {
    double value = 32;
    System.out.println("e to the power value: " +  Math.exp( value ) );
  }
}