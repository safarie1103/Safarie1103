class CharAssassination
{
  public static void main ( String[] args )
  {
    char ch = "A" ;
    System.out.println("A char: " +  ch );
  }
}