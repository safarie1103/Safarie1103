class Shortfall
{
  public static void main ( String[] args )
  {
    short value = 35000;
    System.out.println("A short: " +  value);
  }
}