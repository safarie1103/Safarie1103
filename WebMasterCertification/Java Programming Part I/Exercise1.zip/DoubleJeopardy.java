class DoubleJeopardy
{
  public static void main ( String[] args )
  {
    double value = 32;
    System.out.println("A double: " +  value);
  }
}