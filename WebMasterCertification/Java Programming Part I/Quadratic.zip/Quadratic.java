class Quadratic
{
  public static void main ( String[] args )
  {
    double X = 2/3;
	 System.out.println("X =  " +  X);
    System.out.println("3*X*X - 8X + 4 = " +  (3*X*X - 8*X + 4));
  }
}